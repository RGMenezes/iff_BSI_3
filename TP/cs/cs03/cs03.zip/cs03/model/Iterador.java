package TP.cs.cs03.model;

public interface Iterador {
	
	public boolean temProximo();
	
	public int obterProximoElemento();
}
