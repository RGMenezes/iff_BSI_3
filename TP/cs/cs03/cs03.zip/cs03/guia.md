## 📚 Lista de Exercícios - Estruturas de Dados

* **Professor:** Fábio Duncan 
* **Data:** 06/12/2025
* **Seção 1:** Implementação de Generics

---

### 1. Transformar as implementações dinâmicas de pilha e fila para suportar tipos genéricos