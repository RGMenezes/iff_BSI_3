package TP.cs.cs02.model;

public interface Iterador {
	
	public boolean temProximo();
	
	public int obterProximoElemento();
}
