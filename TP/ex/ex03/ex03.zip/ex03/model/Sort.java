package TP.ex.ex03.model;

public interface Sort {
    void sort(int[] array);
}
